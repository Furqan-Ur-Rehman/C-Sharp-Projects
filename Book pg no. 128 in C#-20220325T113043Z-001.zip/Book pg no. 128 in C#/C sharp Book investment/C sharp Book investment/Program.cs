﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_sharp_Book_investment
{
    class Program
    {
        static void Main(string[] args)
        {
            //*****************For Loop With Missing Portion*******
            int investment;
            int returns;
            int expenses;
            int profit;
            int counter = 0;
            for(investment =1000, returns =0; returns < investment;)
            {
                Console.Write("Enter the monthly Expenditure: ");
                expenses = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the monthly profit: ");
                profit = Convert.ToInt32(Console.ReadLine());

                investment += expenses;
                returns += profit;

                counter++;
            }
            Console.WriteLine("Number of months to break even: " + counter);
            Console.ReadLine();
        }
    }
}
