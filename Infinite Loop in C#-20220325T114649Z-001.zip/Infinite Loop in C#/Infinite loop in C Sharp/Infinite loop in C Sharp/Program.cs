﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infinite_loop_in_C_Sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            //***********************Infinite Loop*****************
            char c;
            int numOne;
            int numTwo;
            int result;
            for(; ; )
            {
                Console.WriteLine("Enter number One: ");
                numOne = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter number Two: ");
                numTwo = Convert.ToInt32(Console.ReadLine());
                result = numOne + numTwo;
                Console.WriteLine("Result of Addition: " + result);
                Console.WriteLine("Do you wish to continue: [Y/N]");
                c = Convert.ToChar(Console.ReadLine());
                if(c == 'Y' || c == 'y')
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
            Console.ReadLine();
        }
    }
}
