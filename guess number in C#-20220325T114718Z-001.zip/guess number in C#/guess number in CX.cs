﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {
            int guess = 0, yournumber;
            //Get a random number between (1 to 10)
            int secretNum = (new Random()).Next(1, 10);
            Console.WriteLine("Pick a number between 1 to 10");
            do
            {
                guess++;
                //Get user Input
                Console.Write("Turn {0} your number: ", guess);
                yournumber = Convert.ToInt32(Console.ReadLine());

                if (yournumber < secretNum)
                {
                    Console.WriteLine("Your guess {0} which is too Low", yournumber);

                }
                else if (yournumber > secretNum)
                {
                    Console.WriteLine("Your guess {0} which is too High", yournumber);
                }
                else
                {
                    Console.WriteLine("Your guess number {0} match the secret Number {1}", secretNum, yournumber);
                }
            }
            while (guess <= 4 && yournumber != secretNum);

            if (guess >= 5)
            {
                Console.WriteLine("You Lost.");
            }
            Console.ReadLine();
        }

    }
}
