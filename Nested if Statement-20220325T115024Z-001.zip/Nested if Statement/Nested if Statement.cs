﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nested If Statement
            int Yearofservices;
            double Salary;
            int bonus = 0;
            Console.WriteLine("Enter the Yearofservices: ");
            Yearofservices = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Salary: ");
            Salary = Convert.ToDouble(Console.ReadLine());

            if (Yearofservices < 5)
            {
                if (Salary < 500)
                {
                    bonus = 100;
                }
                else
                {
                    bonus = 200;
                }
            }
            else
            {
                bonus = 700;
            }
            
            Console.WriteLine("Bonus Amount: " + bonus);
            Console.Read(); 
        }
    }
}
