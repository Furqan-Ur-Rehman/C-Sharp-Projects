﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("According to our job requirement choose only two department: ");
            Console.WriteLine("1: CS Department: ");
            Console.WriteLine("2: IT Department: ");
            Console.WriteLine("Academic Percentage >=60 and Age < 50");
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("If you want to select CS Department then press 1 otherwise for IT Department press 2: ");
            int presskey = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("-------------------------------------");
            if(presskey == 1)
            {
                Console.WriteLine("You have selected CS Department.");
                Console.Write("Enter your Percentage: ");
                int per = Convert.ToInt32(Console.ReadLine());

                if(per >= 60)
                {
                    Console.Write("Enter your Age: ");
                    int Age = Convert.ToInt32(Console.ReadLine());
                    if (Age < 50)
                    {
                        Console.WriteLine("You are Eligible for this post!");

                    }
                    else
                    {
                        Console.WriteLine("You are not Eligible for this post.");
                    }

                }
                else
                {
                    Console.WriteLine("Your percentage is not suitable for this post");
                }
            }

            else if(presskey == 2)
            {
                Console.WriteLine("You have selected IT Department.");
                Console.Write("Enter your Percentage: ");
                int per = Convert.ToInt32(Console.ReadLine());

                if (per >= 60)
                {
                    Console.Write("Enter your Age: ");
                    int Age = Convert.ToInt32(Console.ReadLine());
                    if (Age < 50)
                    {
                        Console.WriteLine("You are Eligible for this post!");

                    }
                    else
                    {
                        Console.WriteLine("You are not Eligible for this post.");
                    }

                }
                else
                {
                    Console.WriteLine("Your percentage is not suitable for this post");
                }
            }
            else
            {
                Console.WriteLine("You are not meet the requirements for the post!");
            }
            Console.Read();
        }
    }
}
