﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public string studentName = "Abc";
        int studAge = 15;

        void Class1()
        {
            Console.WriteLine("Student Name: " + studentName);
            Console.WriteLine("Student Age: " + studAge);
        }
        void Class2()
        {
            Console.WriteLine("Student Name: " + studentName);
            Console.WriteLine("Student Age: " + studAge);
        }
        static void Main(string[] args)
        {
            Program objStud = new Program();
            objStud.Class1();
            objStud.Class2();
            Console.ReadLine();
        }
    }
}
