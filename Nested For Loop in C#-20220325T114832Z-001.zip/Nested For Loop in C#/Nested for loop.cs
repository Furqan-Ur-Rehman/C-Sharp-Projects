﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nested_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int row = 2;
            int col = 2;
            for(int i=0; i<row; i++)
            {
                for(int j=0; j<col; j++)
                {
                    Console.Write("{0}", i * j);
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
