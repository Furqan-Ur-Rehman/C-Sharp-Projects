﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] studentNames = new string[3] { "Ashley", "Joe", "Mikel" };
            foreach(string studName in studentNames)
            {
                Console.WriteLine("Congratulations!! " + studentNames + "You have been granted an extra leave");
            }
            Console.ReadLine();
        }
    }
}
